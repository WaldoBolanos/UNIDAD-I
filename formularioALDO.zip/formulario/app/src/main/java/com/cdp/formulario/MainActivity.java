package com.cdp.formulario;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText nombre, apep, apem, colonia, codp, calle, esdo, muo;
    TextView resul;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nombre = findViewById(R.id.txtnombre);
        apep = findViewById(R.id.txtpaterno);
        apem = findViewById(R.id.txtmaterno);
        colonia = findViewById(R.id.txtcolonia);
        codp = findViewById(R.id.txtcp);
        calle = findViewById(R.id.txtcalle);
        esdo = findViewById(R.id.txtedo);
        muo = findViewById(R.id.txtmunicipio);
        resul = findViewById(R.id.txtresultado);

    }

    public void alta(View view){
        String n = nombre.getText().toString();
        String ama = apem.getText().toString();
        String apa = apep.getText().toString();
        String clnia = colonia.getText().toString();
        String cptal = codp.getText().toString();
        String cal = calle.getText().toString();
        String edo = esdo.getText().toString();
        String muni = muo.getText().toString();

        resul.setText("Nombre: "+n+" Apellido paterno: "+apa+" Apellido materno: "+ama+" Colonia: "+clnia
                +" Codigo postal: "+cptal+" Calle: "+cal+" Estado: "+edo+" Municipio: "+muni);

    }

    public void limpiar(View view){
        resul.setText("");  nombre.setText("");
        apem.setText("");  apep.setText("");
        colonia.setText("");  codp.setText("");
        calle.setText("");  esdo.setText("");
        muo.setText("");
    }
}