package com.example.calculadora;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText num1, num2;
    private TextView txtresult;
    Button btnsum,btnrest,btnmul, btndiv, btncleann;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtresult= (TextView)findViewById(R.id.txtresult);
        num1=(EditText)findViewById(R.id.num1);
        num2=(EditText)findViewById(R.id.num2);
        btnsum=(Button)findViewById(R.id.btnsum);
        btnrest=(Button)findViewById(R.id.btnrest);
        btncleann=(Button)findViewById(R.id.btnclean);


        btnsum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double n1,n2;
                n1=Double.parseDouble(num1.getText().toString());
                n2=Double.parseDouble(num2.getText().toString());

                Double resultado=n1+n2;

                txtresult.setText(""+resultado);


            }

        });
        btnrest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double n1,n2;
                n1=Double.parseDouble(num1.getText().toString());
                n2=Double.parseDouble(num2.getText().toString());

                Double resultado=n1-n2;

                txtresult.setText(""+resultado);


            }


        });

        btnmul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double n1,n2;
                n1=Double.parseDouble(num1.getText().toString());
                n2=Double.parseDouble(num2.getText().toString());

                Double resultado=(n1*n2);

                txtresult.setText(""+resultado);


            }

        });

        btndiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double n1,n2;
                n1=Double.parseDouble(num1.getText().toString());
                n2=Double.parseDouble(num2.getText().toString());

                Double resultado=(n1/n2);

                txtresult.setText(""+resultado);


            }

        });

        btncleann.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num1.setText("");
                num2.setText("");
                txtresult.setText("");

                num1.requestFocus();
            }
        });


    }


}
